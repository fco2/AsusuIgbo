package com.asusuigbo.frank.asusuigbo.models;

public enum UserButton {
    AnswerNotSelected,
    AnswerSelected,
    NextQuestion,
    Finished
}
