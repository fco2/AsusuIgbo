package com.asusuigbo.frank.asusuigbo.adapters

import android.content.Context
import android.content.Intent
import android.content.res.ColorStateList
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.support.v4.content.ContextCompat
import android.support.v7.widget.CardView
import android.support.v7.widget.RecyclerView
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.animation.AnimationUtils
import android.widget.ImageView
import android.widget.TextView
import com.asusuigbo.frank.asusuigbo.LessonActivity
import com.asusuigbo.frank.asusuigbo.R
import com.asusuigbo.frank.asusuigbo.models.LessonInfo

/**
 * Created by Frank on 3/27/2018.
 */
class LessonInfoAdapter(private var lessonList: List<LessonInfo>, var context: Context) : RecyclerView.Adapter<LessonInfoAdapter.CustomViewHolder>(){

    class CustomViewHolder(itemView: View?) : RecyclerView.ViewHolder(itemView) {
        var cardView: CardView? = null
        var imageIndexView: ImageView? = null
        var titleTextView: TextView? = null

        init {
            cardView = itemView!!.findViewById(R.id.card_view_id)
            imageIndexView = itemView.findViewById(R.id.lessonImageId)
            titleTextView = itemView.findViewById(R.id.lessonNameId)
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup?, viewType: Int): CustomViewHolder {
        val view = LayoutInflater.from(parent!!.context)
                .inflate(R.layout.table_of_content_lesson_layout, parent, false)
        return CustomViewHolder(view)
    }

    override fun getItemId(position: Int): Long {
         super.getItemId(position)
         return position.toLong()
    }

    override fun getItemViewType(position: Int): Int {
        super.getItemViewType(position)
        return position
    }

    override fun getItemCount(): Int = this.lessonList.size

    override fun onBindViewHolder(holder: CustomViewHolder?, position: Int) {
        holder!!.imageIndexView!!.setImageResource(this.lessonList[position].imageDrawableIndex)
        holder.titleTextView!!.text = this.lessonList[position].lessonKey
        holder.cardView?.setOnClickListener { v ->

            val intent = Intent(v.context, LessonActivity::class.java)
            var nextLesson = "End of List"
            if(itemCount != (position + 1))
                nextLesson = lessonList[position + 1].lessonKey

            intent.putExtra("NEXT_LESSON", nextLesson)
            intent.putExtra("LESSON_NAME", this.lessonList[position].lessonKey)
            intent.putExtra("LESSON_COUNT", (position + 1))
            // You need this if starting activity outside an activity context
            intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK
            v.context.startActivity(intent)
        }

        if(this.lessonList[position].canViewLesson == "FALSE"){
            val color: Int = ContextCompat.getColor(context, R.color.inactiveCardColor)
            holder.cardView?.cardBackgroundColor = ColorStateList.valueOf(color)
            holder.cardView?.elevation = 0.0f

            //set color filter to make image appear inactive
            val matrix = ColorMatrix()
            matrix.setSaturation(0.0f) //default is 1.0f
            val filter = ColorMatrixColorFilter(matrix)
            holder.imageIndexView?.colorFilter = filter

            val shakeAnimation = AnimationUtils.loadAnimation(context, R.anim.shake_animation)
            //this replaces default onclick for cardView
            holder.cardView?.setOnClickListener{v ->
                v.startAnimation(shakeAnimation)
            }
        }
    }
}